using UnityEngine;

public class PathManager : MonoBehaviour
{
    [Header("Main path waypoints (0 = spawner ... last = scanner)")]
    public Transform[] mainPath;
    [Header("Package defaults")]
    public float packageSpeed = 1.6f;
    public float yOffset = 0f;
}
