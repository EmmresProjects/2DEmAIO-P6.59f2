using UnityEngine;

public class InputListener : MonoBehaviour
{
    void Update()
    {
        if (Input.GetKeyDown(KeyBindings.GetLazada())) GameManager.Instance.PlayerPressedKey(KeyBindings.GetLazada());
        if (Input.GetKeyDown(KeyBindings.GetShopee())) GameManager.Instance.PlayerPressedKey(KeyBindings.GetShopee());
        if (Input.GetKeyDown(KeyBindings.GetTemu())) GameManager.Instance.PlayerPressedKey(KeyBindings.GetTemu());
        if (Input.GetKeyDown(KeyBindings.GetZalora())) GameManager.Instance.PlayerPressedKey(KeyBindings.GetZalora());
        if (Input.GetKeyDown(KeyBindings.GetShein())) GameManager.Instance.PlayerPressedKey(KeyBindings.GetShein());
    }
}
