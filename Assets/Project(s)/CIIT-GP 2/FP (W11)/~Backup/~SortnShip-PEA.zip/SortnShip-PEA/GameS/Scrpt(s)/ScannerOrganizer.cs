using UnityEngine;
using System.Collections.Generic;

[System.Serializable]
public class StoreEntry
{
    public string storeName;
    public Transform[] storePath; // optional intermediate points
    public Transform storeTarget; // final drop point
    public GameObject lockedPrefab;
    public GameObject unlockedPrefab;
    public bool unlocked = true;
    public Color color = Color.white;
}

public class ScannerOrganizer : MonoBehaviour
{
    [Header("Stores (order matters)")]
    public StoreEntry[] stores;

    [Header("Scanner sensor (local offset)")]
    public Vector2 sensorPosition = Vector2.zero;
    public Vector2 sensorSize = new Vector2(1f, 1f);

    [Header("Organizing settings")]
    public float organizingSpeed = 1.5f;
    public float yOffset = 0f;

    public StoreEntry GetStoreByName(string name)
    {
        foreach (var s in stores) if (s.storeName == name) return s;
        return null;
    }

    public StoreEntry GetRandomUnlockedStore()
    {
        List<StoreEntry> unlocked = new List<StoreEntry>();
        foreach (var s in stores) if (s.unlocked) unlocked.Add(s);
        if (unlocked.Count == 0 && stores.Length > 0) return stores[0];
        return unlocked[Random.Range(0, unlocked.Count)];
    }

    public void RoutePackageToStore(Package pkg)
    {
        StoreEntry entry = null;
        if (!string.IsNullOrEmpty(pkg.assignedStore)) entry = GetStoreByName(pkg.assignedStore);
        if (entry == null) entry = GetRandomUnlockedStore();

        List<Transform> fullPath = new List<Transform>();
        fullPath.Add(transform); // start at scanner
        if (entry.storePath != null) fullPath.AddRange(entry.storePath);
        if (entry.storeTarget != null) fullPath.Add(entry.storeTarget);

        pkg.SetPath(fullPath, organizingSpeed, yOffset, entry.storeName);
    }

    public void SetStoreLocked(string storeName, bool locked)
    {
        foreach (var s in stores)
        {
            if (s.storeName == storeName)
            {
                s.unlocked = !locked;
                if (s.lockedPrefab != null && s.unlockedPrefab != null)
                {
                    s.lockedPrefab.SetActive(locked);
                    s.unlockedPrefab.SetActive(!locked);
                }
                break;
            }
        }
    }

    // Visualize sensor in editor
    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Vector3 pos = transform.position + new Vector3(sensorPosition.x, sensorPosition.y, 0f);
        Gizmos.DrawWireCube(pos, new Vector3(sensorSize.x, sensorSize.y, 0.1f));
    }
}
