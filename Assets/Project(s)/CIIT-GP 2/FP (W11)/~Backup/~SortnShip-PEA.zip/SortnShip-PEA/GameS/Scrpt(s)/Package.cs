using UnityEngine;
using System.Collections.Generic;

public class Package : MonoBehaviour
{
    public List<Transform> path = new List<Transform>();
    public float speed = 1.6f;
    public float yOffset = 0f;
    int index = 0;
    public string assignedStore = "";
    public bool isMoving = true;

    void Start()
    {
        if (path.Count > 0)
            transform.position = new Vector3(path[0].position.x, path[0].position.y + yOffset, path[0].position.z);
    }

    void Update()
    {
        if (!isMoving || path.Count == 0) return;
        Transform target = path[index];
        Vector3 targetPos = new Vector3(target.position.x, target.position.y + yOffset, target.position.z);
        transform.position = Vector3.MoveTowards(transform.position, targetPos, speed * Time.deltaTime);
        if (Vector3.Distance(transform.position, targetPos) < 0.01f)
        {
            index++;
            if (index >= path.Count)
            {
                isMoving = false;
                GameManager.Instance.PackageReachedScanner(this);
            }
        }
    }

    public void SetPath(List<Transform> newPath, float newSpeed, float newYOffset, string store = "")
    {
        path = new List<Transform>(newPath);
        speed = newSpeed;
        yOffset = newYOffset;
        assignedStore = store;
        index = 0;
        isMoving = true;
    }
}
