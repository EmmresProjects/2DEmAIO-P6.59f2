using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Spawner : MonoBehaviour
{
    public GameObject packagePrefab;
    public PathManager pathManager;
    public float spawnInterval = 1.2f;
    public Transform[] spawnPoints; // optional; if empty uses pathManager.mainPath[0]
    bool running = false;

    void Start()
    {
        if (pathManager == null) pathManager = FindObjectOfType<PathManager>();
    }

    public void StartSpawning()
    {
        running = true;
        StopAllCoroutines();
        StartCoroutine(SpawnLoop());
    }

    public void StopSpawning()
    {
        running = false;
        StopAllCoroutines();
    }

    IEnumerator SpawnLoop()
    {
        while (running)
        {
            SpawnOne();
            yield return new WaitForSeconds(spawnInterval);
        }
    }

    void SpawnOne()
    {
        Vector3 pos = pathManager.mainPath[0].position;
        if (spawnPoints != null && spawnPoints.Length > 0) pos = spawnPoints[0].position;
        GameObject go = Instantiate(packagePrefab, pos, Quaternion.identity);
        Package pkg = go.GetComponent<Package>();
        List<Transform> path = new List<Transform>(pathManager.mainPath);
        string assigned = GameManager.Instance.GetNextAssignedStore(); // ensures spawn respects level
        pkg.SetPath(path, pathManager.packageSpeed, pathManager.yOffset, assigned);
        GameManager.Instance.RegisterSpawnedPackage(pkg);
    }
}
