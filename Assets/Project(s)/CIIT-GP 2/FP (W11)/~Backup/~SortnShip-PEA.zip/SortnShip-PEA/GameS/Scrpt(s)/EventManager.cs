using UnityEngine;
using TMPro;
using System.Collections;

public class EventManager : MonoBehaviour
{
    public static EventManager Instance;
    public GameObject[] introImages; // SNSCD3, SNSCD2, SNSCD1, SNSCDStart (assign in order)
    public GameObject levelBanner; // panel with TMP_Text child
    public TMP_Text levelBannerText;
    public GameObject winPanel; // panel with TMP_Text and button
    public TMP_Text winPanelText;

    void Awake()
    {
        if (Instance == null) Instance = this; else Destroy(gameObject);
    }

    public IEnumerator PlayIntroThenStart(System.Action onComplete)
    {
        // show intro images in sequence, each 0.6s
        foreach (var img in introImages)
        {
            img.SetActive(true);
            yield return new WaitForSeconds(0.6f);
            img.SetActive(false);
        }
        // final start image briefly
        if (introImages.Length > 0)
        {
            introImages[introImages.Length - 1].SetActive(true);
            yield return new WaitForSeconds(0.6f);
            introImages[introImages.Length - 1].SetActive(false);
        }
        onComplete?.Invoke();
    }

    public IEnumerator ShowLevelBanner(int level)
    {
        levelBannerText.text = "Level " + level;
        levelBanner.SetActive(true);
        // slide from top: simple animation using anchored position if RectTransform, else fade
        RectTransform rt = levelBanner.GetComponent<RectTransform>();
        if (rt != null)
        {
            Vector2 start = new Vector2(rt.anchoredPosition.x, rt.anchoredPosition.y + 200);
            Vector2 end = rt.anchoredPosition;
            float t = 0f;
            while (t < 0.4f)
            {
                t += Time.deltaTime;
                rt.anchoredPosition = Vector2.Lerp(start, end, t / 0.4f);
                yield return null;
            }
        }
        yield return new WaitForSeconds(1.0f);
        levelBanner.SetActive(false);
    }

    public void ShowWinPanel(string text)
    {
        winPanelText.text = text;
        winPanel.SetActive(true);
    }

    public void HideWinPanel()
    {
        winPanel.SetActive(false);
    }
}
