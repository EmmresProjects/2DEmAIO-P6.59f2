using UnityEngine;
using TMPro;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    [Header("Core refs")]
    public PathManager pathManager;
    public Spawner spawner;
    public ScannerOrganizer scanner;
    public EventManager eventManager;

    [Header("UI (TMP)")]
    public TMP_Text scoreText;
    public TMP_Text livesText;
    public TMP_Text levelText;
    public TMP_Text messageText;
    public GameObject queueSlot1; // contains TMP_Text child
    public GameObject queueSlot2;

    [Header("Audio")]
    public AudioSource audioSource;
    public AudioClip correctClip;
    public AudioClip wrongClip;
    public AudioClip winClip;
    public AudioClip loseClip;

    // Level config
    int level = 1;
    int deliveries = 0;
    int target = 20;
    int score = 0;
    int lives = 3;
    List<string> activeStores = new List<string>();
    List<Package> activePackages = new List<Package>();
    Queue<string> spawnQueue = new Queue<string>();

    void Awake()
    {
        if (Instance == null) Instance = this; else Destroy(gameObject);
    }

    void Start()
    {
        messageText.gameObject.SetActive(false);
        // start intro sequence then start gameplay
        StartCoroutine(eventManager.PlayIntroThenStart(() =>
        {
            StartLevel(1);
        }));
    }

    public void StartLevel(int lvl)
    {
        level = lvl;
        deliveries = 0;
        score = 0;
        lives = 3;
        ConfigureLevel(level);
        UpdateUI();
        StartCoroutine(eventManager.ShowLevelBanner(level));
        spawner.StartSpawning();
    }

    void ConfigureLevel(int lvl)
    {
        // set target and speed and active stores per spec
        if (lvl == 1) { target = 20; pathManager.packageSpeed = 1.6f; SetActiveStores(new string[] { "Lazada", "Shopee" }); }
        else if (lvl == 2) { target = 30; pathManager.packageSpeed = 2.0f; SetActiveStores(new string[] { "Lazada", "Shopee", "Temu" }); }
        else if (lvl == 3) { target = 40; pathManager.packageSpeed = 2.6f; SetActiveStores(new string[] { "Lazada", "Shopee", "Temu", "Zalora" }); }
        else { target = 50; pathManager.packageSpeed = 3.2f; SetActiveStores(new string[] { "Lazada", "Shopee", "Temu", "Zalora", "Shein" }); }

        // lock/unlock stores in scanner
        foreach (var s in scanner.stores)
        {
            bool locked = !System.Array.Exists(activeStores.ToArray(), x => x == s.storeName);
            scanner.SetStoreLocked(s.storeName, locked);
        }

        // prepare spawnQueue to ensure only allowed stores spawn
        spawnQueue.Clear();
        // fill queue with random allowed stores to keep preview meaningful
        for (int i = 0; i < 10; i++) spawnQueue.Enqueue(GetRandomAssignedStore());
    }

    public void SetActiveStores(string[] stores)
    {
        activeStores.Clear();
        foreach (var s in stores) activeStores.Add(s);
    }

    public string GetRandomAssignedStore()
    {
        if (activeStores.Count == 0) return "";
        return activeStores[Random.Range(0, activeStores.Count)];
    }

    // Called by Spawner to get next store respecting level
    public string GetNextAssignedStore()
    {
        if (spawnQueue.Count == 0) spawnQueue.Enqueue(GetRandomAssignedStore());
        string s = spawnQueue.Dequeue();
        spawnQueue.Enqueue(GetRandomAssignedStore());
        return s;
    }

    public void RegisterSpawnedPackage(Package p)
    {
        activePackages.Add(p);
        UpdateQueueUI();
    }

    public void PackageReachedScanner(Package pkg)
    {
        // scanner will route it
        scanner.RoutePackageToStore(pkg);
        UpdateQueueUI();
    }

    public void PackageDelivered(Package pkg, bool correct)
    {
        if (correct)
        {
            score += 1;
            deliveries += 1;
            if (audioSource != null && correctClip != null) audioSource.PlayOneShot(correctClip);
        }
        else
        {
            lives -= 1;
            if (audioSource != null && wrongClip != null) audioSource.PlayOneShot(wrongClip);
        }

        if (activePackages.Contains(pkg)) activePackages.Remove(pkg);
        UpdateUI();

        if (lives <= 0) { GameOver(); return; }
        if (deliveries >= target)
        {
            if (level >= 4) // player cleared level 4 -> win
            {
                WinGame();
            }
            else
            {
                spawner.StopSpawning();
                StartLevel(level + 1);
            }
        }
    }

    void UpdateUI()
    {
        if (scoreText != null) scoreText.text = "Score: " + score;
        if (livesText != null) livesText.text = "Lives: " + lives;
        if (levelText != null) levelText.text = "Level: " + level + " / 4";
    }

    void UpdateQueueUI()
    {
        TMP_Text t1 = queueSlot1.GetComponentInChildren<TMP_Text>();
        TMP_Text t2 = queueSlot2.GetComponentInChildren<TMP_Text>();
        if (t1 != null) t1.text = (spawnQueue.Count > 0) ? spawnQueue.Peek() : "-";
        if (t2 != null)
        {
            string[] arr = spawnQueue.ToArray();
            t2.text = (arr.Length > 1) ? arr[1] : "-";
        }
    }

    public KeyCode GetKeyForStore(string store)
    {
        switch (store)
        {
            case "Lazada": return KeyBindings.GetLazada();
            case "Shopee": return KeyBindings.GetShopee();
            case "Temu": return KeyBindings.GetTemu();
            case "Zalora": return KeyBindings.GetZalora();
            case "Shein": return KeyBindings.GetShein();
            default: return KeyCode.None;
        }
    }

    public void PlayerPressedKey(KeyCode key)
    {
        if (activePackages.Count == 0) return;
        // find package nearest to scanner (smallest x distance)
        Package nearest = null;
        float bestDist = float.MaxValue;
        foreach (var p in activePackages)
        {
            if (p == null) continue;
            float dx = Mathf.Abs(p.transform.position.x - scanner.transform.position.x);
            if (dx < bestDist) { bestDist = dx; nearest = p; }
        }
        if (nearest == null) return;

        string assigned = nearest.assignedStore;
        KeyCode correctKey = GetKeyForStore(assigned);
        if (key == correctKey)
        {
            // correct: immediate deliver and score
            PackageDelivered(nearest, true);
            Destroy(nearest.gameObject);
        }
        else
        {
            // wrong: penalize and send to random unlocked store
            var wrong = scanner.GetRandomUnlockedStore();
            if (wrong != null) nearest.assignedStore = wrong.storeName;
            PackageDelivered(nearest, false);
            Destroy(nearest.gameObject);
        }
    }

    void GameOver()
    {
        spawner.StopSpawning();
        messageText.gameObject.SetActive(true);
        messageText.text = "Game Over";
        if (audioSource != null && loseClip != null) audioSource.PlayOneShot(loseClip);
    }

    void WinGame()
    {
        spawner.StopSpawning();
        eventManager.ShowWinPanel("You Win! Play Endless?"); // shows win panel
        if (audioSource != null && winClip != null) audioSource.PlayOneShot(winClip);
    }
}
