using UnityEngine;

/// - In the Button OnClick() list, add this component and choose UIButtonSFX.Play.
public class UIButtonSFX : MonoBehaviour
{
    public AudioClip clip; // assign per-button SFX in inspector
    public void Play()
    {
        if (AudioManager.Instance != null)
        {
            AudioManager.Instance.PlaySFX(clip);
        }
        else
        {
            if (clip != null)
            {
                AudioSource.PlayClipAtPoint(clip, Camera.main != null ? Camera.main.transform.position : Vector3.zero);
            }
        }
    }
}
