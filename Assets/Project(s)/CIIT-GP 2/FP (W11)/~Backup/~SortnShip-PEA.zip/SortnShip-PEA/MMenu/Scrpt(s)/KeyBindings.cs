using UnityEngine;

/// <summary>
/// Static helper to get current key bindings from PlayerPrefs.
/// Use GameManager or other gameplay scripts to query keys.
/// </summary>
public static class KeyBindings
{
    const string PREF_KEY_LAZADA = "PREF_KEY_LAZADA";
    const string PREF_KEY_SHOPEE = "PREF_KEY_SHOPEE";
    const string PREF_KEY_TEMU = "PREF_KEY_TEMU";
    const string PREF_KEY_ZALORA = "PREF_KEY_ZALORA";
    const string PREF_KEY_SHEIN = "PREF_KEY_SHEIN";

    public static KeyCode GetLazada() => (KeyCode)PlayerPrefs.GetInt(PREF_KEY_LAZADA, (int)KeyCode.LeftArrow);
    public static KeyCode GetShopee() => (KeyCode)PlayerPrefs.GetInt(PREF_KEY_SHOPEE, (int)KeyCode.DownArrow);
    public static KeyCode GetTemu() => (KeyCode)PlayerPrefs.GetInt(PREF_KEY_TEMU, (int)KeyCode.UpArrow);
    public static KeyCode GetZalora() => (KeyCode)PlayerPrefs.GetInt(PREF_KEY_ZALORA, (int)KeyCode.RightArrow);
    public static KeyCode GetShein() => (KeyCode)PlayerPrefs.GetInt(PREF_KEY_SHEIN, (int)KeyCode.Space);
}
