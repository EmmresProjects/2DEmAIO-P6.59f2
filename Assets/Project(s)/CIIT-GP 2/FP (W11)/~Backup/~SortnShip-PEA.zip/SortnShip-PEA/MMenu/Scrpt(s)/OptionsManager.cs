using System;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// Options manager using TextMeshPro labels with conflict detection and prevention.
/// Attach to OptionsManager GameObject and assign TMP label references and panels in inspector.
/// </summary>
public class OptionsManager : MonoBehaviour
{
    [Header("UI Elements")]
    public GameObject optionsPanel;
    public Slider volumeSlider;
    public Button backButton;
    public Button resetDefaultsButton;

    [Header("Key Remap Rows (TextMeshPro)")]
    public TextMeshProUGUI lazadaLabel;
    public Button lazadaRemapButton;
    public TextMeshProUGUI shopeeLabel;
    public Button shopeeRemapButton;
    public TextMeshProUGUI temuLabel;
    public Button temuRemapButton;
    public TextMeshProUGUI zaloraLabel;
    public Button zaloraRemapButton;
    public TextMeshProUGUI sheinLabel;
    public Button sheinRemapButton;

    [Header("Conflict / Alert Panels")]
    // Panel shown when a key conflict is detected (Replace / Cancel)
    public GameObject conflictPanel;
    public TextMeshProUGUI conflictText;
    public Button conflictReplaceButton;
    public Button conflictCancelButton;

    // Simple alert panel used to show messages (OK)
    public GameObject alertPanel;
    public TextMeshProUGUI alertText;
    public Button alertOkButton;

    // Internal state for remapping
    private bool waitingForKey = false;
    private string currentTargetPref = null; // which PREF_KEY_* we are remapping now
    private Action<KeyCode> onKeyCaptured;

    // Pending conflict resolution state
    private KeyCode pendingCapturedKey = KeyCode.None;
    private string pendingOwnerPref = null;   // the pref key that currently owns the captured key
    private string pendingTargetPref = null;  // the pref key we attempted to assign

    // PlayerPrefs keys
    const string PREF_VOLUME = "PREF_MASTER_VOLUME";
    const string PREF_KEY_LAZADA = "PREF_KEY_LAZADA";
    const string PREF_KEY_SHOPEE = "PREF_KEY_SHOPEE";
    const string PREF_KEY_TEMU = "PREF_KEY_TEMU";
    const string PREF_KEY_ZALORA = "PREF_KEY_ZALORA";
    const string PREF_KEY_SHEIN = "PREF_KEY_SHEIN";

    void Start()
    {
        // Load saved settings or defaults
        float vol = PlayerPrefs.GetFloat(PREF_VOLUME, 1f);
        if (volumeSlider != null) volumeSlider.value = vol;
        if (AudioManager.Instance != null) AudioManager.Instance.SetMasterVolume(vol);

        // Wire UI
        if (volumeSlider != null) volumeSlider.onValueChanged.AddListener(OnVolumeChanged);
        if (backButton != null) backButton.onClick.AddListener(OnBackClicked);
        if (resetDefaultsButton != null) resetDefaultsButton.onClick.AddListener(OnResetDefaults);

        if (lazadaRemapButton != null) lazadaRemapButton.onClick.AddListener(() => StartKeyRemap(PREF_KEY_LAZADA, (k) => { PlayerPrefs.SetInt(PREF_KEY_LAZADA, (int)k); UpdateAllKeyLabels(); }));
        if (shopeeRemapButton != null) shopeeRemapButton.onClick.AddListener(() => StartKeyRemap(PREF_KEY_SHOPEE, (k) => { PlayerPrefs.SetInt(PREF_KEY_SHOPEE, (int)k); UpdateAllKeyLabels(); }));
        if (temuRemapButton != null) temuRemapButton.onClick.AddListener(() => StartKeyRemap(PREF_KEY_TEMU, (k) => { PlayerPrefs.SetInt(PREF_KEY_TEMU, (int)k); UpdateAllKeyLabels(); }));
        if (zaloraRemapButton != null) zaloraRemapButton.onClick.AddListener(() => StartKeyRemap(PREF_KEY_ZALORA, (k) => { PlayerPrefs.SetInt(PREF_KEY_ZALORA, (int)k); UpdateAllKeyLabels(); }));
        if (sheinRemapButton != null) sheinRemapButton.onClick.AddListener(() => StartKeyRemap(PREF_KEY_SHEIN, (k) => { PlayerPrefs.SetInt(PREF_KEY_SHEIN, (int)k); UpdateAllKeyLabels(); }));

        // Conflict panel buttons
        if (conflictReplaceButton != null) conflictReplaceButton.onClick.AddListener(OnConflictReplace);
        if (conflictCancelButton != null) conflictCancelButton.onClick.AddListener(OnConflictCancel);

        // Alert panel OK
        if (alertOkButton != null) alertOkButton.onClick.AddListener(() => { if (alertPanel != null) alertPanel.SetActive(false); });

        // Ensure panels hidden
        if (conflictPanel != null) conflictPanel.SetActive(false);
        if (alertPanel != null) alertPanel.SetActive(false);

        UpdateAllKeyLabels();
    }

    void Update()
    {
        // If waiting for a key, capture any key down
        if (waitingForKey)
        {
            if (Input.anyKeyDown)
            {
                foreach (KeyCode kc in Enum.GetValues(typeof(KeyCode)))
                {
                    if (Input.GetKeyDown(kc))
                    {
                        waitingForKey = false;
                        HandleCapturedKey(kc);
                        break;
                    }
                }
            }
        }
    }

    void OnVolumeChanged(float value)
    {
        if (AudioManager.Instance != null) AudioManager.Instance.SetMasterVolume(value);
        PlayerPrefs.SetFloat(PREF_VOLUME, value);
    }

    /// <summary>
    /// Called when Back is clicked. Prevent closing if any key is unassigned (KeyCode.None).
    /// </summary>
    void OnBackClicked()
    {
        // Check all key prefs
        if (IsAnyKeyEmpty())
        {
            ShowAlert("One or more store keys are unassigned. Please assign keys before leaving Options.");
            return;
        }

        if (optionsPanel != null) optionsPanel.SetActive(false);
    }

    void OnResetDefaults()
    {
        // Reset volume
        PlayerPrefs.SetFloat(PREF_VOLUME, 1f);
        if (volumeSlider != null) volumeSlider.value = 1f;
        if (AudioManager.Instance != null) AudioManager.Instance.SetMasterVolume(1f);

        // Reset keys to defaults
        PlayerPrefs.SetInt(PREF_KEY_LAZADA, (int)KeyCode.LeftArrow);
        PlayerPrefs.SetInt(PREF_KEY_SHOPEE, (int)KeyCode.DownArrow);
        PlayerPrefs.SetInt(PREF_KEY_TEMU, (int)KeyCode.UpArrow);
        PlayerPrefs.SetInt(PREF_KEY_ZALORA, (int)KeyCode.RightArrow);
        PlayerPrefs.SetInt(PREF_KEY_SHEIN, (int)KeyCode.Space);

        UpdateAllKeyLabels();
    }

    /// <summary>
    /// Begin remapping a key for the given PlayerPrefs key name.
    /// </summary>
    void StartKeyRemap(string prefKey, Action<KeyCode> onCaptured)
    {
        if (waitingForKey) return;
        waitingForKey = true;
        currentTargetPref = prefKey;
        onKeyCaptured = onCaptured;

        // Visual feedback
        if (prefKey == PREF_KEY_LAZADA && lazadaLabel != null) lazadaLabel.text = "Lazada: Press any key...";
        if (prefKey == PREF_KEY_SHOPEE && shopeeLabel != null) shopeeLabel.text = "Shopee: Press any key...";
        if (prefKey == PREF_KEY_TEMU && temuLabel != null) temuLabel.text = "Temu: Press any key...";
        if (prefKey == PREF_KEY_ZALORA && zaloraLabel != null) zaloraLabel.text = "Zalora: Press any key...";
        if (prefKey == PREF_KEY_SHEIN && sheinLabel != null) sheinLabel.text = "Shein: Press any key...";
    }

    /// <summary>
    /// Handle a captured key: check for conflicts, show conflict panel if needed, otherwise assign immediately.
    /// </summary>
    void HandleCapturedKey(KeyCode kc)
    {
        // Find if some other pref already uses this key
        string ownerPref = GetOwnerPrefKey(kc);

        // If owner exists and it's not the same as the current target, show conflict
        if (!string.IsNullOrEmpty(ownerPref) && ownerPref != currentTargetPref)
        {
            // Save pending state
            pendingCapturedKey = kc;
            pendingOwnerPref = ownerPref;
            pendingTargetPref = currentTargetPref;

            // Show conflict panel
            if (conflictPanel != null && conflictText != null)
            {
                string ownerName = PrefKeyToStoreName(ownerPref);
                string targetName = PrefKeyToStoreName(currentTargetPref);
                conflictText.text = $"The key {kc} is already assigned to {ownerName}.\nDo you want to replace it and assign to {targetName}?";
                conflictPanel.SetActive(true);
            }
            else
            {
                // If no conflict panel assigned, fallback to automatic cancel
                CancelRemapVisual(currentTargetPref);
            }
            // Do not call onKeyCaptured yet; wait for user decision
            return;
        }

        // No conflict or owner is same as target: assign directly
        AssignKeyToPref(currentTargetPref, kc);
        onKeyCaptured?.Invoke(kc);
        onKeyCaptured = null;
        currentTargetPref = null;
        pendingCapturedKey = KeyCode.None;
        UpdateAllKeyLabels();
    }

    /// <summary>
    /// Called when user chooses Replace in the conflict panel.
    /// Clears the previous owner's binding (sets to KeyCode.None) and assigns the key to the target.
    /// </summary>
    void OnConflictReplace()
    {
        if (string.IsNullOrEmpty(pendingOwnerPref) || string.IsNullOrEmpty(pendingTargetPref))
        {
            CloseConflictPanel();
            return;
        }

        // Clear previous owner
        PlayerPrefs.SetInt(pendingOwnerPref, (int)KeyCode.None);

        // Assign new key to target
        AssignKeyToPref(pendingTargetPref, pendingCapturedKey);

        // Persist and update labels
        UpdateAllKeyLabels();

        // Clear pending state and close panel
        pendingCapturedKey = KeyCode.None;
        pendingOwnerPref = null;
        pendingTargetPref = null;
        CloseConflictPanel();
    }

    /// <summary>
    /// Called when user cancels the conflict dialog.
    /// Restores the visual label for the target pref and cancels remap.
    /// </summary>
    void OnConflictCancel()
    {
        // Restore visual label for the target pref
        CancelRemapVisual(pendingTargetPref);

        // Clear pending state
        pendingCapturedKey = KeyCode.None;
        pendingOwnerPref = null;
        pendingTargetPref = null;
        CloseConflictPanel();
    }

    void CloseConflictPanel()
    {
        if (conflictPanel != null) conflictPanel.SetActive(false);
        // Ensure we are not waiting for key anymore
        waitingForKey = false;
        currentTargetPref = null;
        onKeyCaptured = null;
    }

    void CancelRemapVisual(string prefKey)
    {
        // Restore label text to current saved key
        if (prefKey == PREF_KEY_LAZADA && lazadaLabel != null) lazadaLabel.text = "Lazada: " + GetKeyName(PREF_KEY_LAZADA, KeyCode.LeftArrow);
        if (prefKey == PREF_KEY_SHOPEE && shopeeLabel != null) shopeeLabel.text = "Shopee: " + GetKeyName(PREF_KEY_SHOPEE, KeyCode.DownArrow);
        if (prefKey == PREF_KEY_TEMU && temuLabel != null) temuLabel.text = "Temu: " + GetKeyName(PREF_KEY_TEMU, KeyCode.UpArrow);
        if (prefKey == PREF_KEY_ZALORA && zaloraLabel != null) zaloraLabel.text = "Zalora: " + GetKeyName(PREF_KEY_ZALORA, KeyCode.RightArrow);
        if (prefKey == PREF_KEY_SHEIN && sheinLabel != null) sheinLabel.text = "Shein: " + GetKeyName(PREF_KEY_SHEIN, KeyCode.Space);
    }

    /// <summary>
    /// Assigns a KeyCode to a PlayerPrefs pref name.
    /// </summary>
    void AssignKeyToPref(string prefKey, KeyCode kc)
    {
        if (string.IsNullOrEmpty(prefKey)) return;
        PlayerPrefs.SetInt(prefKey, (int)kc);
    }

    /// <summary>
    /// Returns the PlayerPrefs key name that currently owns the given KeyCode, or null if none.
    /// </summary>
    string GetOwnerPrefKey(KeyCode kc)
    {
        if ((KeyCode)PlayerPrefs.GetInt(PREF_KEY_LAZADA, (int)KeyCode.LeftArrow) == kc) return PREF_KEY_LAZADA;
        if ((KeyCode)PlayerPrefs.GetInt(PREF_KEY_SHOPEE, (int)KeyCode.DownArrow) == kc) return PREF_KEY_SHOPEE;
        if ((KeyCode)PlayerPrefs.GetInt(PREF_KEY_TEMU, (int)KeyCode.UpArrow) == kc) return PREF_KEY_TEMU;
        if ((KeyCode)PlayerPrefs.GetInt(PREF_KEY_ZALORA, (int)KeyCode.RightArrow) == kc) return PREF_KEY_ZALORA;
        if ((KeyCode)PlayerPrefs.GetInt(PREF_KEY_SHEIN, (int)KeyCode.Space) == kc) return PREF_KEY_SHEIN;
        return null;
    }

    /// <summary>
    /// Convert pref key name to a human store name for messages.
    /// </summary>
    string PrefKeyToStoreName(string prefKey)
    {
        switch (prefKey)
        {
            case PREF_KEY_LAZADA: return "Lazada";
            case PREF_KEY_SHOPEE: return "Shopee";
            case PREF_KEY_TEMU: return "Temu";
            case PREF_KEY_ZALORA: return "Zalora";
            case PREF_KEY_SHEIN: return "Shein";
            default: return "Unknown";
        }
    }

    void UpdateAllKeyLabels()
    {
        if (lazadaLabel != null) lazadaLabel.text = "Lazada: " + GetKeyName(PREF_KEY_LAZADA, KeyCode.LeftArrow);
        if (shopeeLabel != null) shopeeLabel.text = "Shopee: " + GetKeyName(PREF_KEY_SHOPEE, KeyCode.DownArrow);
        if (temuLabel != null) temuLabel.text = "Temu: " + GetKeyName(PREF_KEY_TEMU, KeyCode.UpArrow);
        if (zaloraLabel != null) zaloraLabel.text = "Zalora: " + GetKeyName(PREF_KEY_ZALORA, KeyCode.RightArrow);
        if (sheinLabel != null) sheinLabel.text = "Shein: " + GetKeyName(PREF_KEY_SHEIN, KeyCode.Space);
    }

    string GetKeyName(string prefKey, KeyCode defaultKey)
    {
        int val = PlayerPrefs.GetInt(prefKey, (int)defaultKey);
        KeyCode kc = (KeyCode)val;
        if (kc == KeyCode.None) return "Unassigned";
        return kc.ToString();
    }

    bool IsAnyKeyEmpty()
    {
        if ((KeyCode)PlayerPrefs.GetInt(PREF_KEY_LAZADA, (int)KeyCode.LeftArrow) == KeyCode.None) return true;
        if ((KeyCode)PlayerPrefs.GetInt(PREF_KEY_SHOPEE, (int)KeyCode.DownArrow) == KeyCode.None) return true;
        if ((KeyCode)PlayerPrefs.GetInt(PREF_KEY_TEMU, (int)KeyCode.UpArrow) == KeyCode.None) return true;
        if ((KeyCode)PlayerPrefs.GetInt(PREF_KEY_ZALORA, (int)KeyCode.RightArrow) == KeyCode.None) return true;
        if ((KeyCode)PlayerPrefs.GetInt(PREF_KEY_SHEIN, (int)KeyCode.Space) == KeyCode.None) return true;
        return false;
    }

    void ShowAlert(string message)
    {
        if (alertPanel != null && alertText != null)
        {
            alertText.text = message;
            alertPanel.SetActive(true);
        }
        else
        {
            // Fallback: use Debug.Log if no alert panel assigned
            Debug.LogWarning(message);
        }
    }
}
